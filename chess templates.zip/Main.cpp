#include "MoveGenerator.h"
#include "Cui.h"
#include <chrono>
#include <bitset>

#include <iostream>
#include <fstream>

using namespace std::chrono;

int main()
{
    game::init();

    setFen(StartPosition);

    Cui cui;

    return 0;
}